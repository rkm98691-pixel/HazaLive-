HAZA LIVE Android starter (demo)

इस प्रोजेक्ट में browser demo को Android WebView ऐप में पैक किया गया है।
यह अभी production app नहीं है:
- coins demo/local हैं, server पर सुरक्षित नहीं हैं
- live voice room / multi-user seats असली backend से जुड़े नहीं हैं
- admin panel केवल demo है
- real money, cash-out या redeemable prizes नहीं हैं

APK बनाने का cloud तरीका:
1. GitHub पर नया repository बनाएं।
2. इस ZIP को extract करके सभी files repository में upload करें।
3. Branch का नाम main रखें।
4. GitHub repository में Actions खोलें।
5. "Build Haza Live APK" workflow चलाएं (Run workflow)।
6. पूरा होने पर workflow के Artifacts में Haza-Live-debug-APK डाउनलोड करें।

ध्यान दें: इस ZIP में पहले से बना APK शामिल नहीं है। GitHub Actions इसे build करेगा।
